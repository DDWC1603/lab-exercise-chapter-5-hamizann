//finish up this program.thanks.

#include <iostream>
#include <iomanip>

using namespace std;

void ombakOmbak(int repeat=3,int height=5,int up=2,int down=2)
{
	while(repeat >0)
	{
		for(/*up*/)
		cout<<setw(height)<<right<<"+"<<endl;
		for(/*down*/)
		cout<<"+"<<endl;
		repeat --;
	}
}



void OmbakKeluar()
{

	cout<<"\nwaveDemo\n";
	petakPelik();
}

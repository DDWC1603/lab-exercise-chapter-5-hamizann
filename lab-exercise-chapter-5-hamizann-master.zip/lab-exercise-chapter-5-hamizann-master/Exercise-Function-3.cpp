//complete the program below
//its a program to find the average value.

int main()
{
	double m=0.0;
	double n=0.0;

	cout<<"Enter first number"<<endl;
	
	cout<<"Enter second number"<<endl;
	
	std::cin.get();

	cout<<"Average is: "<</*function here*/<<endl;
	
	
	
}

double avg(double x,double y)
{
	/*return the average value of x and y*/

	
}

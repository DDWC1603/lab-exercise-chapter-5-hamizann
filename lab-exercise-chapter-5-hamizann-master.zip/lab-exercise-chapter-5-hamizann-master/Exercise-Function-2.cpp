//this is an unfinish program
//finish up this program

int sum(int x,int y)
{
	int result;
	result = x+y;

}
